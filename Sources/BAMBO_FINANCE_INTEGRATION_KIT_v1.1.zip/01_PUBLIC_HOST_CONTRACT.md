# Public Host Contract

Status: external, sanitized, minimum contract. This document does not describe production endpoints.

## Verified host facts

| Fact | Contract |
|---|---|
| Backend compatibility | Python 3.12, FastAPI, Pydantic v2 |
| Database compatibility | PostgreSQL 16 is the production baseline; every Finance SQL/migration deliverable must also pass PostgreSQL 18; do not use PG17+ only features |
| Organization identifier | UUID string |
| Project identifier | stable text matching `^[A-Za-z0-9_-]+$`; it is not a UUID |
| Project status | `active`, `closed`, or `archived` |
| Authentication boundary | server-side opaque session; details are intentionally excluded; host supplies validated context |
| Tenant boundary | application-enforced organization and project scope |
| Frontend compatibility | plain HTML/CSS/vanilla ES modules, RTL, no build step or CDN |

## Minimum organization view

`id`, `name`, `code`, `status`, and the caller's membership are sufficient. The organization is active when `status == "active"`. For Finance MVP, project owner means the Organization Head/President already represented by BAMBO; the Finance module must not invent another owner identity.

## Minimum project view

`id`, `organization_id`, `name`, `code`, `status`, and `gross_built_area`. The current host project model has no gross-built-area field. The adapter therefore exposes a finance-owned extension value, represented as a decimal string and square-metre unit, without modifying or disclosing unrelated project internals.

## Required validation

The route path plus validated `AuthContext` establishes effective scope. Body values cannot establish or override scope.

```text
authenticate -> organization membership -> project belongs to organization
             -> project membership -> finance permission -> scoped operation
```

Every finance record and query carries both `organization_id` and `project_id`. Even an object lookup by globally unique identifier must also filter by both scope keys. Unauthorized collection access returns 403; an inaccessible object or file returns 404 when hiding existence is required.

## Examples

| Situation | Result |
|---|---|
| Member of organization and project with `finance.view` | allow read |
| User requests another organization | 403 |
| Same organization but no membership in requested project | 403 |
| Body contains different organization/project IDs | ignore body scope; use path and AuthContext |
| No finance permission | 403 |
| Existing file belongs to another scope | 404 |

The mock routes are examples only and all carry the marker `MOCK DEVELOPMENT CONTRACT — NOT A PRODUCTION BAMBO ENDPOINT`. Production-facing BAMBO JSON uses `camelCase`; database columns and internal Python variables may remain `snake_case`.
