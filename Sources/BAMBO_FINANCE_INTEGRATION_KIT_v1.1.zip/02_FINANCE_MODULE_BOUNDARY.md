# Finance Module Boundary

## In scope for the future module

- Four finance resource types: `material` (متریال), `labor` (نیروی انسانی), `equipment` (دستگاه و تجهیزات), and `general_cost` (هزینه عمومی).
- One finance estimate line for each activity/resource assignment; resource-level aggregation remains possible through `resource_external_id`.
- Original and revised quantities with append-only revision audit.
- Organization base prices and optional project overrides, with append-only history.
- Manual, Excel, or progress-feed resource sources.
- Multi-line invoices, extraction drafts, confirmation, void/reversal/corrective links.
- Consumed quantity fallback, unit conversions, immutable report snapshots, dashboard/HTML/browser print/CSV reports.
- Gross built area as finance-owned project extension data.

## Outside MVP / outside this kit

- Payment and treasury tracking; every confirmed invoice counts as actual cost regardless of payment.
- Inventory/warehouse. Purchased and consumed quantities remain separate.
- Direct opening or parsing of MPP/MSP files.
- Internet price providers or provider-specific AI.
- Final finance database schema/migrations, BAMBO adapters, production routes, and the Finance implementation.

## Financial definitions

All monetary values cross JSON boundaries as integer-IRR strings and are exact decimals internally. Quantities and conversion factors remain decimal strings.

| Metric | Definition |
|---|---|
| Original estimate | original quantity × original unit price |
| Actual registered cost | sum of confirmed invoice line/header allocation amounts |
| Current value of executed work | consumed/executed quantity × current unit price |
| Remaining physical cost | remaining physical quantity × current unit price |
| Money required to continue | material: unpurchased quantity × current price; labor/equipment: unexecuted quantity × current price; general cost: `max(revised amount - actual confirmed cost, 0)` |
| Forecast final cost | actual registered cost + money required to continue; for general cost this therefore equals `actual + max(revised - actual, 0)` |
| Actual cost per square metre | actual registered cost ÷ gross built area |
| Forecast cost per square metre | forecast final cost ÷ gross built area |

Division by a missing/zero area must yield an unavailable metric plus a validation warning, never infinity or a guessed number.

## Immutability rules

- Never overwrite original estimates, historical prices, confirmed invoices, or issued reports.
- A quantity revision records previous/new value, reason, actor, and timestamp.
- A confirmed invoice is corrected only by void, reversal, or corrective invoice linked to the original.
- A report snapshot pins progress snapshot, estimate/resource versions, price versions, confirmed invoice set, conversion versions, and calculated metrics.

## Ownership and deletion

Financial history must survive host project/organization lifecycle changes. Final schema must use restrictive/no-action references or preserved identifiers; never cascade-delete financial history. Soft deletion is auditable and cannot physically remove confirmed records.
