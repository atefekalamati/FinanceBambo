# Progress Report to Finance Feed Contract

The Finance module never reads MPP files. BAMBO Progress Report imports them and publishes a standardized, read-only, versioned snapshot:

`Microsoft Project -> Progress Report -> finance feed snapshot -> Finance`

## Snapshot

Metadata includes both scope IDs, `progress_snapshot_id`, `source_file_version_id`, safe display filename, importer and import time, reporting date, and status. Tasks carry stable external/task hierarchy fields. Assignments carry resource identity/type/unit and optional quantity/work measures.

Each activity/resource assignment is a separate finance line. Repeated use of the same resource is aggregated only by explicit resource identity, never by mutable title.

## Executed quantity fallback

1. `actual_quantity`, or assignment `actual_work` when the unit/dimension contract makes work the quantity.
2. assignment work-complete percent × planned assignment quantity.
3. task progress percent × planned resource quantity.
4. manual override.

The selected `source_method` is one of `assignment_actual`, `assignment_work_percent`, `task_progress_fallback`, `manual_override`, `excel_import`, `manual_entry`. A quality value from 0 to 1 and warnings explain the choice.

A manual override is valid only when it records previous calculated value, new value, non-empty reason, actor ID, UTC timestamp, `source: manual_override`, and related progress snapshot ID. The original computed value remains available.

## Null and quantity rules

- Missing is `null`, not zero.
- A `general_cost` may have `planned_quantity`, `actual_quantity`, `remaining_quantity`, and `unit` all null.
- Percentages range from 0 to 100. Calculated quantities may exceed plan but must produce an auditable warning rather than silent clamping.
- Finance treats every snapshot as immutable and does not write back to Progress Report.

`samples/progress-feed-task-only.json` demonstrates current task-progress fallback. `samples/progress-feed-assignment-level.json` demonstrates future assignment actuals. `samples/progress-feed-manual-override.json` demonstrates audited override.
