# Authentication and Permission Contract

## Abstract host interface

```text
AuthContextProvider.current(request) -> AuthContext
ScopeAuthorizer.require_organization(context, organization_id)
ScopeAuthorizer.require_project(context, organization_id, project_id)
PermissionAuthorizer.require(context, permission_code)
```

The host resolves and validates the real opaque session before calling Finance. Session storage, token format, cookie value, lookup logic, and credential flows are deliberately absent from this kit.

The mock uses `X-Mock-User` only to select synthetic contexts. That mechanism is insecure outside local development and must not be copied into production.

## Four independent gates

1. Authentication: a valid current user exists.
2. Organization membership: the user belongs to the path organization.
3. Project membership: the user may access the path project and it belongs to that organization.
4. Finance permission: the requested action is granted in the validated scope.

All four are server-side requirements. UI visibility is convenience only.

## EXISTING permissions (verified)

- `finance.view`
- `finance.edit`
- `finance_report.view`
- `finance_report.export`

These are the only finance permission codes this kit treats as current production facts.

## PROPOSED permissions (not production facts)

The verified BAMBO permission naming contract is exactly `<module>.<action>` (one dot only). Multi-dot codes such as `finance.invoice.confirm` are invalid for this host. Proposed codes for Finance MVP are:

- `finance.manage_resources`
- `finance.manage_estimates`
- `finance.manage_prices`
- `finance.create_invoice`
- `finance.confirm_invoice`
- `finance.manage_invoice`
- `finance.void_invoice`
- `finance.manage_settings`
- `finance.override_progress`
- `finance.view_attachments`
- `finance_report.issue`

Every proposed code requires BAMBO product/security approval and RBAC seeding before merge. Until then, the host adapter may map an approved action to an existing coarse permission; the mapping must be explicit, reviewed, and tested. Do not silently seed or assume a proposed permission.

## Suggested action matrix pending approval

| Action | Existing fallback | Proposed target |
|---|---|---|
| Read finance data | `finance.view` | keep existing read gate; narrower read permissions are not required for MVP |
| Edit resources/estimates/prices | `finance.edit` | `finance.manage_resources` / `finance.manage_estimates` / `finance.manage_prices` |
| Create invoice | `finance.edit` | `finance.create_invoice` |
| Confirm/void invoice | no automatic fallback decision | `finance.confirm_invoice` / `finance.void_invoice` |
| View/export reports | `finance_report.view` / `.export` | keep existing |
| Issue immutable report | no existing decision | `finance_report.issue` |

Confirmation, void, progress override, attachment viewing, report issuance, and the final mapping of proposed permissions are merge-blocking permission decisions.
