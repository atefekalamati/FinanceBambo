# File, Image, Voice, and AI Confirmation Contract

## Provider-neutral interfaces

```text
InvoiceImageExtractor.extract(file, hints) -> ExtractionDraft
InvoiceVoiceExtractor.extract(file, hints) -> ExtractionDraft
FinanceFileStorage.put/get(metadata, bytes) -> StoredFile
ExtractionConfirmationService.confirm(draft_id, edits, actor) -> ConfirmedInvoice
```

No provider is selected. Provider credentials/configuration belong in external environment configuration and never in source or samples. Failure must leave an uploaded file available for manual entry.

## Upload controls

- Accept only `invoice_image` or `invoice_voice` through multipart upload.
- Product limits are fixed for MVP: image **10 MiB**, voice **25 MiB**. The BAMBO core team must verify edge/reverse-proxy compatibility with these limits before merge; edge verification does not reopen the product limit.
- Image allowlist: JPEG, PNG, WebP. GIF and SVG are not allowed.
- Voice allowlist: MP3, M4A, WAV, OGG. WebM is not part of the MVP allowlist.
- Derive a safe random storage name; retain the original name only as display metadata after removing path components/control characters.
- Validate extension, declared MIME, and magic bytes. Reject executable/web content.
- Store `organizationId`, `projectId`, uploader, exact byte size, MIME, SHA-256, logical type, and processing status.
- Serve through a finance-authorized endpoint. Cross-scope/not-visible files return 404.

The in-memory mock demonstrates metadata and ownership only; it is not production storage, malware scanning, or reconciliation.

## Three independent lifecycles

Do not use one generic `status` for attachment processing, AI review, and invoice lifecycle. They are separate fields and separate state machines.

### A. File processing (`processingStatus`)

```text
uploaded -> processing -> ready
                    \-> failed -> processing (retry)
```

`processingStatus` never becomes `confirmed`, `voided`, or `corrected`. Those are invoice concepts.

### B. AI extraction review (`reviewStatus`)

```text
awaitingReview -> accepted
               \-> rejected
```

The extraction draft has zero financial effect by itself. Every extracted field retains extracted value, confidence, user-confirmed value, and whether the user edited it.

### C. Invoice lifecycle (`invoiceStatus`)

```text
draft -> awaitingConfirmation -> confirmed
confirmed -> linked void/reversal/corrective record (original remains immutable)
```

The API status vocabulary for invoices is `draft`, `awaitingConfirmation`, `confirmed`, `voided`, `corrected`. Confirmation of an AI-created invoice atomically marks the extraction review `accepted` and the invoice `confirmed`; the file processing state remains independent. Direct file/extraction status changes must never be interpreted as financial confirmation.

Before invoice confirmation, the draft contributes exactly zero to actual cost. Confirmation records actor and UTC time. After confirmation, the invoice is immutable and corrections use linked void/reversal/corrective records.

## Concurrency and idempotency

Confirmation checks the expected draft version and current invoice status. A repeated request with the same idempotency key returns the same outcome; competing confirmations produce a conflict. The confirmer must be the submitting user for MVP and must also pass scope and `finance.confirm_invoice` (or an explicitly approved temporary coarse mapping) checks.
