# Database Compatibility (Design Guidance Only)

No production migration is included or executed. Final SQL is reviewed and merged by the BAMBO core team.

## Type conventions

| Concern | Requirement |
|---|---|
| Organization FK value | `uuid NOT NULL` |
| Project FK value | `text NOT NULL` |
| Finance entity IDs | generated immutable UUID; never mutable-title-derived |
| Money / monetary unit price | **integer IRR**: `numeric(18,0)`, Python `Decimal`, JSON string; API rejects fractional-IRR input before persistence |
| Quantity / conversion factor | `numeric(18,4)` or higher documented precision, JSON string |
| System timestamps | `timestamptz`, UTC, ISO-8601 JSON |
| Business dates | PostgreSQL `date` recommended; Jalali conversion only in UI |
| Statuses | `text` plus `CHECK`; do not introduce PostgreSQL ENUM |

`numeric(18,0)` is an exact numeric with scale zero. Multiplying decimal quantity by integer-IRR unit price may produce a fractional IRR during calculation; line money is rounded once with the centrally defined `ROUND_HALF_UP` policy to a whole IRR. Floating-point types are forbidden for money and financial calculations.

## Isolated illustrative shape

Names below are examples, not migrations: `finance_mock_projects`, `finance_mock_price_versions`, `finance_mock_invoices`, and `finance_mock_report_snapshots`. Every financial table stores both scope keys. Foreign keys to financial history use `RESTRICT`/`NO ACTION`, never project-to-history cascade. Host deletion must be reconciled with preserved finance ownership before production design approval.

All foreign-key and frequent scope/filter columns need explicit indexes. Useful composite indexes begin with `(organization_id, project_id, ...)`. Uniqueness must include tenant scope where appropriate. Parameterized SQL is mandatory; sort expressions come from an allowlist.

## History and audit

- **Price history is strictly append-only.** Creating a new price inserts a new version and never updates the previous historical row, including no `effective_to` update.
- A price version stores `effective_from` plus immutable creation/version metadata. The valid price for an `as_of` date/time is the newest version with `effective_from <= as_of`; if several corrections share an effective date, the newest immutable version/recorded time wins by a deterministic rule documented in the final schema. Issued reports pin the exact price-version ID.
- Original estimate and every revision are distinct immutable versions.
- Confirmed invoices cannot be updated/deleted; corrections link to the original.
- Issued report snapshots pin all input-version IDs and calculated metrics.
- Audit fields include actor, UTC time, action, reason where applicable, and before/after values.
- Soft-deleted mutable drafts use `deleted_at`/`deleted_by`; all reads filter them explicitly.

## Compatibility gate

PostgreSQL **16 is the production baseline and all Finance SQL/migration deliverables must also pass PostgreSQL 18**. SQL must run idempotently on both versions, without extensions or PG17+ only features such as `UNIQUE NULLS NOT DISTINCT`. No ORM/query builder/Alembic is assumed. Never use floating point for money, silent history overwrite, cascade deletion of financial history, or identifiers derived from names.
