# UI Integration Contract

The public-safe demonstration is `ui/rtl-module-shell.html`; it contains no copied proprietary page or asset.

## Mount contract

- Document root uses `lang="fa" dir="rtl"`.
- Host provides a sidebar slot, project-context slot, notification live region, and `<main id="finance-module-root">` mount.
- Finance navigation appears as «مالی» and uses existing coarse permission visibility until finer permissions are approved.
- All security decisions remain server-side.

## Required states

Every page must render loading, empty, recoverable error, permission denied, and normal content. Confirmation of invoice/void/report issue uses an accessible modal with explicit action and cancellation; destructive or immutable transitions cannot occur from a single ambiguous click.

## Compatibility

Plain HTML, CSS and vanilla JavaScript ES modules only; no bundler, framework, external font/CDN/chart library, or external browser request. Components should accept host data through adapter functions and relative same-origin URLs. Use CSS logical properties, visible focus, Persian labels, ASCII numeric API values, and Persian digit formatting only for display.

Print reports use browser printing with A4 CSS and wait for fonts/images. CSV is UTF-8 with BOM. `ui/public-design-tokens.css` contains only generic spacing, radius, typography, neutral/brand-compatible colors, forms, tables, focus, responsive, and print rules.

## Integration handoff

The external team delivers self-contained finance HTML/ES modules/styles plus a small documented adapter patch request. The BAMBO core team performs any allowlist, authenticated-page, menu, permission, or backend-router changes internally after review.
