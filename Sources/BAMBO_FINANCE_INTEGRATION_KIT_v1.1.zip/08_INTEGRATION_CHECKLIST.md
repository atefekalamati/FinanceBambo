# BAMBO Core Integration Checklist

## Before handing this kit to the external team

- [ ] Security review completed
- [ ] No secrets, real data, production URLs, private domains/ports, or infrastructure details
- [ ] No internal session implementation or unrelated source
- [ ] All samples validate; all OpenAPI documents parse
- [ ] Mock and contract tests pass offline
- [ ] ZIP excludes `dist/` and checksum matches

## Before accepting the Finance module

- [ ] Runs against mock host and all contract tests pass
- [ ] No dependency on `X-Mock-User` or any mock-only authentication
- [ ] No hard-coded organization/project and no unscoped finance query
- [ ] Every record carries both scope IDs; cross-tenant/project and file tests pass
- [ ] No floating-point money; decimal strings cross JSON boundaries
- [ ] No direct MPP parsing or direct production file path
- [ ] AI extraction remains provider-neutral and draft until human confirmation
- [ ] Confirmed invoices are immutable; corrections are linked
- [ ] Price and estimate histories are append-only
- [ ] Issued reports are immutable snapshots
- [ ] Purchased and consumed quantities remain separate; no inventory claim
- [ ] No payment/treasury behavior is implied
- [ ] All migrations and dependency changes await core approval
- [ ] Security review passed

## Before merge

- [ ] Internal host/auth/scope/file/progress adapters implemented
- [ ] Existing-to-proposed permission mapping approved and RBAC seeded internally
- [ ] Final database migrations reviewed and tested on PostgreSQL 16 and 18
- [ ] Tenant isolation, IDOR, file-access, concurrency, and immutability tests pass
- [ ] Backup created and restore/rollback plan documented
- [ ] Private staging verification completed with synthetic data
- [ ] Production migration executed only by BAMBO core team
