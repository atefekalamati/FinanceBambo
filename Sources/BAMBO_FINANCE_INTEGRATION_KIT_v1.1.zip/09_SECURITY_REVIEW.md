# Security Review

Result: **PASS for external development distribution, subject to the acceptance gates below.** This is a review of the kit, not a production-readiness approval for the future Finance module.

## Controls present

- Synthetic-only fixtures and `example.invalid` contact data.
- No source copy, real records, environment values, session internals, infrastructure addresses, private domains/ports, or provider credentials.
- Mock authentication is loudly labelled local-only.
- Dual organization/project scoping, membership, and permission gates are exercised.
- Inaccessible scoped objects/files conceal existence with 404 where appropriate.
- Body scope override is ignored.
- Exact decimal contracts; append-only prices/estimates; immutable invoices/reports.
- Draft-only AI extraction, confirmation audit, provider-neutral interfaces.
- File ownership, size, MIME, hash, generated name, and dedicated authorized retrieval contract.
- No external network dependency in application or UI assets.

## Threats and required production controls

| Risk | Required control before merge |
|---|---|
| Cross-tenant/project IDOR | central host scope adapter plus negative tests on every route/query |
| Financial attachment disclosure | dedicated authorization, content disposition, no direct static path, 404 concealment |
| Malicious upload | extension/MIME/magic-byte allowlist, size limits, malware-scanning decision, safe decoding |
| Duplicate/racing confirmation | idempotency key, optimistic version/status check, database transaction |
| Money/rounding errors | Decimal/numeric and one centrally tested rounding policy |
| History rewrite/deletion | DB constraints/triggers where appropriate, restrictive FKs, audit and corrective flow |
| AI error/provider outage | human confirmation, confidence/warnings, manual fallback, no totals before confirmation |
| Snapshot drift | immutable version references and reproducibility checks |

## Deliberate limitations

The in-memory mock is not durable storage, antivirus, production authentication, database concurrency, or a migration proof. PostgreSQL 16/18 execution, **edge compatibility with the fixed 10 MiB image / 25 MiB voice product limits**, security headers/CSRF strategy, backup/restore, observability, and real adapter behavior remain internal pre-merge verification items. The upload size values themselves are not open product decisions.

No external-team deliverable may be treated as safe merely because it passes this kit; BAMBO core must perform source review, dependency/secret scanning, tenant isolation tests, migration review, restore drill, and private staging verification.
