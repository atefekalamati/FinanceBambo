# Changelog

## 1.1.0 — 2026-08-08

- Reconciled Integration Kit with BAMBO Finance MVP PRD v1.1.
- Standardized money to integer IRR (`numeric(18,0)`), strict append-only price versions, and separate file/AI/invoice lifecycles.
- Fixed product upload limits/formats, PG16/18 gate, general-cost rule, retention/pagination/SLA decisions, duplicate/idempotency rules, and gross-area ownership.
- Aligned public JSON examples/contracts to BAMBO `camelCase` and corrected proposed permission names to the verified one-dot `<module>.<action>` convention.

## 1.0.0 — 2026-08-06

- Created sanitized standalone host, auth, progress, file/AI, database, UI, and security contracts.
- Added four OpenAPI 3.1 documents, ten JSON Schemas, synthetic samples, six mock user scenarios, RTL shell, and offline contract/security tests.
- Documented verified compatibility facts, existing versus proposed permissions, and unresolved product/technical decisions.
