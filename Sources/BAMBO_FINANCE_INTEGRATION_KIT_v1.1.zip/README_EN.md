# BAMBO Finance Integration Kit

Version: 1.1.0 — sanitized external-development package.

This kit lets an external team build and test a Finance module without BAMBO source code, live databases, customer data, infrastructure, secrets, or private session details. It is a contract and host simulator, not the Finance module and not a production BAMBO API.

## Safe boundary

- Every identity, project, organization, file, amount, and date is synthetic.
- Every `/mock/...` route is labelled **MOCK DEVELOPMENT CONTRACT — NOT A PRODUCTION BAMBO ENDPOINT**.
- `X-Mock-User` is a local-only scenario selector. It must never be copied into production.
- The real host must inject an already authenticated `AuthContext`; the external module must not read or validate BAMBO sessions.
- No network access is required. Uploaded test files remain in the mock process memory.

## Quick start

Python 3.12+ and the dependencies in `mock-host/requirements.txt` are required.

```powershell
cd docs/finance-integration-kit
py -3 -m pip install -r mock-host/requirements.txt
py -3 tests/run_contract_tests.py
py -3 mock-host/run_local.py
```

Open `http://127.0.0.1:8765/`. API docs are at `/docs`. The default scenario is `org-head`; choose another scenario with `X-Mock-User`.

## Integration sequence

1. Develop only against the schemas, OpenAPI documents, samples, and mock routes in this kit.
2. Keep finance storage independently scoped by both `organization_id` and `project_id`.
3. Implement host adapters behind the public interfaces; do not depend on mock authentication.
4. Run `py -3 tests/run_contract_tests.py` before delivery.
5. BAMBO core reviews permissions, migrations, adapters, tenant isolation, file access, rollback, and staging before merge.

## Contents

- `01_...` through `10_...`: public contracts, boundaries, checklists, security review, and Persian PRD inputs.
- `openapi/`: four limited, mock-only OpenAPI 3.1 contracts.
- `schemas/` and `samples/`: JSON Schema 2020-12 contracts and synthetic examples.
- `mock-host/`: standalone FastAPI simulator.
- `ui/`: public-safe RTL shell and design tokens.
- `tests/`: offline contract and security checks.
- `dist/`: distributable ZIP and SHA-256 digest, created after validation.

## Explicit exclusions

The kit does not implement accounting, payment/treasury, inventory, direct MPP parsing, provider-specific AI, production adapters, final database migrations, or the Finance module itself.
