"""Synthetic fixtures only. No BAMBO database access is performed."""

ORG_A = "11111111-1111-4111-8111-111111111111"
ORG_B = "22222222-2222-4222-8222-222222222222"
PROJECT_A = "sample_site_01"
PROJECT_A_OTHER = "sample_site_02"
PROJECT_B = "other_site_01"

USERS = {
    "org-head": {
        "userId": "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1", "organizationId": ORG_A,
        "projectId": PROJECT_A, "organizationRole": "org_chief", "projectRole": "project_admin",
        "permissionCodes": ["finance.view", "finance_report.view", "finance_report.export"],
        "organizationMemberships": [ORG_A], "projectMemberships": [PROJECT_A],
    },
    "finance-editor": {
        "userId": "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2", "organizationId": ORG_A,
        "projectId": PROJECT_A, "organizationRole": "finance_viewer", "projectRole": "editor",
        "permissionCodes": ["finance.view", "finance.edit", "finance_report.view", "finance_report.export"],
        "organizationMemberships": [ORG_A], "projectMemberships": [PROJECT_A],
    },
    "project-manager": {
        "userId": "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa3", "organizationId": ORG_A,
        "projectId": PROJECT_A, "organizationRole": "viewer", "projectRole": "project_manager",
        "permissionCodes": ["finance.view"], "organizationMemberships": [ORG_A], "projectMemberships": [PROJECT_A],
    },
    "finance-viewer": {
        "userId": "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa4", "organizationId": ORG_A,
        "projectId": PROJECT_A, "organizationRole": "finance_viewer", "projectRole": "viewer",
        "permissionCodes": ["finance.view", "finance_report.view"],
        "organizationMemberships": [ORG_A], "projectMemberships": [PROJECT_A],
    },
    "other-organization": {
        "userId": "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb5", "organizationId": ORG_B,
        "projectId": PROJECT_B, "organizationRole": "org_chief", "projectRole": "project_admin",
        "permissionCodes": ["finance.view", "finance.edit", "finance_report.view", "finance_report.export"],
        "organizationMemberships": [ORG_B], "projectMemberships": [PROJECT_B],
    },
    "no-finance": {
        "userId": "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa6", "organizationId": ORG_A,
        "projectId": PROJECT_A, "organizationRole": "viewer", "projectRole": "viewer",
        "permissionCodes": [], "organizationMemberships": [ORG_A], "projectMemberships": [PROJECT_A],
    },
}

for _user in USERS.values():
    _user["locale"] = "fa-IR"
    _user["timezone"] = "Asia/Tehran"

ORGANIZATIONS = {
    ORG_A: {"id": ORG_A, "name": "سازمان نمونه آفتاب", "code": "org-101", "status": "active", "headUserId": USERS["org-head"]["userId"]},
    ORG_B: {"id": ORG_B, "name": "سازمان ساختگی دیگر", "code": "org-202", "status": "active", "headUserId": USERS["other-organization"]["userId"]},
}

PROJECTS = {
    PROJECT_A: {"id": PROJECT_A, "organizationId": ORG_A, "name": "پروژه ساختگی آفتاب", "code": "project-201", "status": "active", "grossBuiltArea": "4250.0000", "grossBuiltAreaUnit": "m2"},
    PROJECT_A_OTHER: {"id": PROJECT_A_OTHER, "organizationId": ORG_A, "name": "پروژه ساختگی دوم", "code": "project-202", "status": "active", "grossBuiltArea": "1800.0000", "grossBuiltAreaUnit": "m2"},
    PROJECT_B: {"id": PROJECT_B, "organizationId": ORG_B, "name": "پروژه ساختگی سازمان دیگر", "code": "project-301", "status": "active", "grossBuiltArea": "3100.0000", "grossBuiltAreaUnit": "m2"},
}
