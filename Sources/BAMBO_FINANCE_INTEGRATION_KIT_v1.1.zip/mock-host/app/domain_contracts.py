"""Small executable invariants; these are contracts, not a Finance implementation."""

from __future__ import annotations

from copy import deepcopy
from decimal import Decimal, ROUND_HALF_UP
from types import MappingProxyType


def decimal_value(value: str | None) -> Decimal | None:
    return None if value is None else Decimal(value)


def irr_value(value: str) -> Decimal:
    amount = Decimal(value)
    if amount != amount.to_integral_value():
        raise ValueError("IRR money must be an integer amount")
    return amount


def consumed_quantity(assignment: dict) -> tuple[Decimal, str]:
    if assignment.get("sourceMethod") == "manual_override":
        override = assignment.get("manualOverride") or {}
        required = ("previousCalculatedValue", "newValue", "reason", "userId", "occurredAt", "source", "progressSnapshotId")
        if any(not override.get(key) for key in required) or override.get("source") != "manual_override":
            raise ValueError("manual override requires complete audit metadata")
        return Decimal(override["newValue"]), "manual_override"
    if assignment.get("actualQuantity") is not None:
        return Decimal(assignment["actualQuantity"]), "assignment_actual"
    planned = decimal_value(assignment.get("plannedQuantity"))
    if planned is not None and assignment.get("assignmentWorkCompletePercent") is not None:
        return planned * Decimal(assignment["assignmentWorkCompletePercent"]) / Decimal("100"), "assignment_work_percent"
    task_percent = assignment.get("task", {}).get("taskProgressPercent")
    if planned is not None and task_percent is not None:
        return planned * Decimal(task_percent) / Decimal("100"), "task_progress_fallback"
    raise ValueError("manual override is required when no calculation source exists")


def append_price(history: tuple[dict, ...], amount: str, effective_date: str, version_id: str) -> tuple[dict, ...]:
    new_version = {"versionId": version_id, "amountIRR": str(irr_value(amount)), "effectiveFrom": effective_date}
    return history + (new_version,)


def invoice_line(quantity: str, unit_price: str, price_version_id: str) -> dict:
    unit_price_irr = irr_value(unit_price)
    amount = (Decimal(quantity) * unit_price_irr).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return {"quantity": quantity, "unitPriceIRRSnapshot": str(unit_price_irr), "priceVersionId": price_version_id, "lineAmountIRR": str(amount)}


def draft_financial_effect(draft: dict) -> Decimal:
    return Decimal("0") if draft.get("invoiceStatus") != "confirmed" else irr_value(draft["financialEffectIRR"])


def confirm_draft(draft: dict, actor_user_id: str, confirmed_at: str, amount: str) -> dict:
    if draft.get("reviewStatus") != "awaitingReview" or draft.get("invoiceStatus") != "awaitingConfirmation" or actor_user_id != draft.get("submittedBy"):
        raise ValueError("only the submitting user may confirm an awaiting AI invoice draft")
    result = deepcopy(draft)
    result.update(reviewStatus="accepted", invoiceStatus="confirmed", confirmedBy=actor_user_id, confirmedAt=confirmed_at, financialEffectIRR=str(irr_value(amount)))
    return result


def resolve_conversion(conversions: list[dict], organization_id: str, project_id: str, source: str, target: str) -> Decimal:
    eligible = [row for row in conversions if row["organizationId"] == organization_id and row["sourceUnit"] == source and row["targetUnit"] == target and row.get("projectId") in (None, project_id)]
    if not eligible:
        raise LookupError("conversion not found")
    eligible.sort(key=lambda row: (row.get("projectId") == project_id, row["effectiveDate"]), reverse=True)
    return Decimal(eligible[0]["factor"])


def immutable_report_snapshot(payload: dict):
    required = ("progressSnapshotId", "resourceVersionIds", "priceVersionIds", "invoiceIds", "unitConversionIds", "calculatedMetrics")
    if not payload.get("immutable") or not all(payload.get(key) is not None for key in required):
        raise ValueError("issued report must pin all source versions")
    return MappingProxyType(deepcopy(payload))
