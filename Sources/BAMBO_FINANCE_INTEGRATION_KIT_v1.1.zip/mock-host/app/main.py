"""FastAPI surface for the sanitized Finance host simulator."""

from pathlib import Path

from fastapi import FastAPI, File, Form, Header, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import CONTRACT_MARKER
from .service import ContractError, context, get_file, load_feed, organization_context, project_context, upload_file

KIT_ROOT = Path(__file__).resolve().parents[2]
app = FastAPI(title="BAMBO Finance Mock Host", version="1.1.0", description=CONTRACT_MARKER)
app.mount("/mock/static", StaticFiles(directory=KIT_ROOT / "mock-host" / "static"), name="mock-static")


@app.exception_handler(ContractError)
async def contract_error_handler(_request: Request, exc: ContractError):
    return JSONResponse(status_code=exc.status, content=exc.envelope())


@app.get("/", response_class=HTMLResponse)
def home():
    return (KIT_ROOT / "mock-host" / "templates" / "index.html").read_text(encoding="utf-8")


@app.get("/mock/health")
def health():
    return {"status": "ok", "contractMarker": CONTRACT_MARKER, "networkRequired": False}


@app.get("/mock/context/me")
def me(x_mock_user: str = Header(default="org-head")):
    return context(x_mock_user)


@app.get("/mock/organizations/{organizationId}")
def organization(organizationId: str, x_mock_user: str = Header(default="org-head")):
    return organization_context(x_mock_user, organizationId)


@app.get("/mock/organizations/{organizationId}/projects/{projectId}")
def project(organizationId: str, projectId: str, x_mock_user: str = Header(default="org-head")):
    return project_context(x_mock_user, organizationId, projectId)


@app.get("/mock/organizations/{organizationId}/projects/{projectId}/finance-progress-feed")
def progress_feed(organizationId: str, projectId: str, mode: str = "task-only", x_mock_user: str = Header(default="org-head")):
    return load_feed(KIT_ROOT, x_mock_user, organizationId, projectId, mode)


@app.post("/mock/organizations/{organizationId}/projects/{projectId}/finance-files", status_code=201)
async def create_file(
    organizationId: str,
    projectId: str,
    logicalType: str = Form(...),
    file: UploadFile = File(...),
    organizationIdBody: str | None = Form(default=None, alias="organizationId"),
    projectIdBody: str | None = Form(default=None, alias="projectId"),
    x_mock_user: str = Header(default="org-head"),
):
    # Body scope fields are deliberately ignored; path + validated context win.
    _ = organizationIdBody, projectIdBody
    data = await file.read()
    return upload_file(x_mock_user, organizationId, projectId, logicalType, file.filename or "upload.bin", data)


@app.get("/mock/organizations/{organizationId}/projects/{projectId}/finance-files/{fileId}")
def file_metadata(organizationId: str, projectId: str, fileId: str, x_mock_user: str = Header(default="org-head")):
    return get_file(x_mock_user, organizationId, projectId, fileId)
