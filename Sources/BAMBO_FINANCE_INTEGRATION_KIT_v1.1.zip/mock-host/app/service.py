"""Framework-independent mock rules used by FastAPI and offline tests."""

from __future__ import annotations

import hashlib
import json
import re
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from . import CONTRACT_MARKER
from .data import ORGANIZATIONS, PROJECTS, USERS

FILES: dict[str, dict] = {}


class ContractError(Exception):
    def __init__(self, status: int, code: str, message: str):
        super().__init__(message)
        self.status, self.code, self.message = status, code, message

    def envelope(self) -> dict:
        return {"error": {"code": self.code, "message": self.message, "requestId": f"req-{uuid4()}", "details": []}}


def context(scenario: str | None) -> dict:
    if not scenario or scenario not in USERS:
        raise ContractError(401, "UNAUTHENTICATED", "Select a valid local mock scenario.")
    raw = deepcopy(USERS[scenario])
    for private_key in ("organizationMemberships", "projectMemberships"):
        raw.pop(private_key, None)
    return raw


def raw_user(scenario: str | None) -> dict:
    if not scenario or scenario not in USERS:
        raise ContractError(401, "UNAUTHENTICATED", "Select a valid local mock scenario.")
    return USERS[scenario]


def require_scope(scenario: str, organization_id: str, project_id: str | None = None, permission: str | None = None) -> dict:
    user = raw_user(scenario)
    if organization_id not in user["organizationMemberships"]:
        raise ContractError(403, "FORBIDDEN", "Organization membership is required.")
    if project_id is not None:
        project = PROJECTS.get(project_id)
        if not project or project["organizationId"] != organization_id or project_id not in user["projectMemberships"]:
            raise ContractError(403, "FORBIDDEN", "Project membership is required.")
    if permission and permission not in user["permissionCodes"]:
        raise ContractError(403, "FORBIDDEN", f"Permission {permission} is required.")
    return user


def organization_context(scenario: str, organization_id: str) -> dict:
    user = require_scope(scenario, organization_id)
    org = ORGANIZATIONS.get(organization_id)
    if not org:
        raise ContractError(404, "NOT_FOUND", "Organization was not found in this scope.")
    result = deepcopy(org)
    result["membership"] = {"userId": user["userId"], "role": user["organizationRole"]}
    return result


def project_context(scenario: str, organization_id: str, project_id: str) -> dict:
    user = require_scope(scenario, organization_id, project_id, "finance.view")
    result = deepcopy(PROJECTS[project_id])
    result["membership"] = {"userId": user["userId"], "role": user["projectRole"]}
    return result


def load_feed(kit_root: Path, scenario: str, organization_id: str, project_id: str, mode: str) -> dict:
    require_scope(scenario, organization_id, project_id, "finance.view")
    names = {"task-only": "progress-feed-task-only.json", "assignment-level": "progress-feed-assignment-level.json", "manual-override": "progress-feed-manual-override.json"}
    if mode not in names:
        raise ContractError(422, "VALIDATION_ERROR", "Unsupported feed mode.")
    payload = json.loads((kit_root / "samples" / names[mode]).read_text(encoding="utf-8"))
    # Samples belong only to the primary synthetic scope; do not relabel cross-tenant data.
    if payload["snapshot"]["organizationId"] != organization_id or payload["snapshot"]["projectId"] != project_id:
        raise ContractError(404, "NOT_FOUND", "No feed exists in this scope.")
    return payload


def _safe_name(name: str) -> str:
    clean = re.sub(r"[\\/:*?\"<>|\x00-\x1f]", "_", Path(name).name).strip(" .")
    return clean[:120] or "upload.bin"


def _detect(data: bytes, logical_type: str) -> tuple[str, str]:
    image = [(b"\x89PNG\r\n\x1a\n", "image/png", "png"), (b"\xff\xd8\xff", "image/jpeg", "jpg"), (b"RIFF", "image/webp", "webp")]
    audio = [(b"OggS", "audio/ogg", "ogg"), (b"RIFF", "audio/wav", "wav"), (b"ID3", "audio/mpeg", "mp3")]
    if logical_type == "invoice_image":
        allowed = image
    elif logical_type == "invoice_voice":
        if len(data) >= 12 and data[4:8] == b"ftyp":
            return "audio/mp4", "m4a"
        allowed = audio
    else:
        allowed = []
    for signature, mime, ext in allowed:
        if data.startswith(signature):
            if mime == "image/webp" and (len(data) < 12 or data[8:12] != b"WEBP"):
                continue
            return mime, ext
    raise ContractError(415, "UNSUPPORTED_MEDIA_TYPE", "File bytes do not match the fixed MVP allowlist for the selected logical type.")

def upload_file(scenario: str, organization_id: str, project_id: str, logical_type: str, original_name: str, data: bytes) -> dict:
    user = require_scope(scenario, organization_id, project_id, "finance.edit")
    maximum = 10 * 1024 * 1024 if logical_type == "invoice_image" else 25 * 1024 * 1024
    if not data:
        raise ContractError(422, "VALIDATION_ERROR", "File is empty.")
    if len(data) > maximum:
        raise ContractError(413, "FILE_TOO_LARGE", "File exceeds the mock limit.")
    mime, extension = _detect(data, logical_type)
    file_id = str(uuid4())
    metadata = {
        "fileId": file_id, "organizationId": organization_id, "projectId": project_id,
        "logicalType": logical_type, "originalNameSafe": _safe_name(original_name),
        "storedName": f"{file_id}.{extension}", "mimeType": mime, "sizeBytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(), "uploadedBy": user["userId"],
        "uploadedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"), "processingStatus": "uploaded",
    }
    FILES[file_id] = deepcopy(metadata)
    return metadata


def get_file(scenario: str, organization_id: str, project_id: str, file_id: str) -> dict:
    try:
        require_scope(scenario, organization_id, project_id, "finance.view")
    except ContractError:
        raise ContractError(404, "NOT_FOUND", "File was not found in this scope.")
    metadata = FILES.get(file_id)
    if not metadata or metadata["organizationId"] != organization_id or metadata["projectId"] != project_id:
        raise ContractError(404, "NOT_FOUND", "File was not found in this scope.")
    return deepcopy(metadata)


def marker_payload(payload: dict) -> dict:
    return {"contractMarker": CONTRACT_MARKER, **payload}
