"""Run the mock host on loopback only.

FastAPI is preferred when the declared local dependencies are installed. A
standard-library fallback keeps the kit runnable and self-testable offline.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import threading
from email import policy
from email.parser import BytesParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.request import urlopen

HOST = "127.0.0.1"
PORT = 8765
MOCK_ROOT = Path(__file__).resolve().parent
KIT_ROOT = MOCK_ROOT.parent
sys.path.insert(0, str(MOCK_ROOT))

from app import CONTRACT_MARKER
from app.service import ContractError, context, get_file, load_feed, organization_context, project_context, upload_file


class FallbackHandler(BaseHTTPRequestHandler):
    """Dependency-free local adapter; it is still a mock, never production auth."""

    server_version = "BamboFinanceMock/1.0"

    def log_message(self, format, *args):
        print("mock:", format % args)

    def _json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _scenario(self):
        return self.headers.get("X-Mock-User", "org-head")

    def _dispatch(self):
        from urllib.parse import parse_qs, urlparse
        parsed = urlparse(self.path)
        path, query = parsed.path, parse_qs(parsed.query)
        if path == "/mock/health":
            return 200, {"status": "ok", "contractMarker": CONTRACT_MARKER, "networkRequired": False, "adapter": "stdlib-fallback"}
        if path == "/mock/context/me":
            return 200, context(self._scenario())
        match = re.fullmatch(r"/mock/organizations/([^/]+)", path)
        if match:
            return 200, organization_context(self._scenario(), match.group(1))
        match = re.fullmatch(r"/mock/organizations/([^/]+)/projects/([^/]+)", path)
        if match:
            return 200, project_context(self._scenario(), match.group(1), match.group(2))
        match = re.fullmatch(r"/mock/organizations/([^/]+)/projects/([^/]+)/finance-progress-feed", path)
        if match:
            return 200, load_feed(KIT_ROOT, self._scenario(), match.group(1), match.group(2), query.get("mode", ["task-only"])[0])
        match = re.fullmatch(r"/mock/organizations/([^/]+)/projects/([^/]+)/finance-files/([^/]+)", path)
        if match:
            return 200, get_file(self._scenario(), match.group(1), match.group(2), match.group(3))
        raise ContractError(404, "NOT_FOUND", "Mock route was not found.")

    def do_GET(self):
        try:
            if self.path == "/":
                body = (MOCK_ROOT / "templates" / "index.html").read_bytes()
                self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body); return
            if self.path.startswith("/mock/static/"):
                name = Path(self.path).name
                target = MOCK_ROOT / "static" / name
                if not target.is_file(): raise ContractError(404, "NOT_FOUND", "Static mock asset was not found.")
                body = target.read_bytes(); mime = "text/css" if target.suffix == ".css" else "text/javascript"
                self.send_response(200); self.send_header("Content-Type", f"{mime}; charset=utf-8"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body); return
            status, payload = self._dispatch(); self._json(status, payload)
        except ContractError as exc:
            self._json(exc.status, exc.envelope())

    def do_POST(self):
        try:
            match = re.fullmatch(r"/mock/organizations/([^/]+)/projects/([^/]+)/finance-files", self.path)
            if not match: raise ContractError(404, "NOT_FOUND", "Mock route was not found.")
            content_type = self.headers.get("Content-Type", "")
            if not content_type.startswith("multipart/form-data"):
                raise ContractError(422, "VALIDATION_ERROR", "multipart/form-data is required.")
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length)
            message = BytesParser(policy=policy.default).parsebytes(f"Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n".encode() + raw)
            fields, file_name, file_bytes = {}, "upload.bin", b""
            for part in message.iter_parts():
                name = part.get_param("name", header="content-disposition")
                if part.get_filename() is not None:
                    file_name, file_bytes = part.get_filename(), part.get_payload(decode=True)
                elif name:
                    fields[name] = part.get_content()
            payload = upload_file(self._scenario(), match.group(1), match.group(2), fields.get("logicalType", ""), file_name, file_bytes)
            self._json(201, payload)
        except (ContractError, ValueError) as exc:
            if isinstance(exc, ContractError): self._json(exc.status, exc.envelope())
            else: self._json(422, ContractError(422, "VALIDATION_ERROR", str(exc)).envelope())


def fallback_server(port: int = PORT):
    return ThreadingHTTPServer((HOST, port), FallbackHandler)


def self_check() -> int:
    server = fallback_server(0)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        port = server.server_address[1]
        with urlopen(f"http://{HOST}:{port}/mock/health", timeout=5) as response:
            payload = json.loads(response.read().decode("utf-8"))
        if response.status != 200 or payload.get("networkRequired") is not False:
            raise RuntimeError("mock health contract failed")
        print(f"SELF_CHECK_OK adapter={payload['adapter']} marker={payload['contract_marker']}")
        return 0
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=5)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-check", action="store_true", help="Start on an ephemeral loopback port, call health, and stop.")
    args = parser.parse_args()
    if args.self_check:
        return self_check()
    try:
        import uvicorn
    except ImportError:
        print(f"FastAPI dependencies unavailable; starting dependency-free local fallback at http://{HOST}:{PORT}")
        fallback_server().serve_forever()
        return 0
    uvicorn.run("app.main:app", host=HOST, port=PORT, reload=False, app_dir=str(MOCK_ROOT))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
