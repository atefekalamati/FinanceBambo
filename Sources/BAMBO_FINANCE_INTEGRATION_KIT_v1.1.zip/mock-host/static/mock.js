document.querySelector('#load').addEventListener('click', async () => {
  const output = document.querySelector('#output');
  output.textContent = 'loading…';
  try {
    const response = await fetch('/mock/context/me', {headers: {'X-Mock-User': document.querySelector('#scenario').value}});
    output.textContent = JSON.stringify(await response.json(), null, 2);
  } catch (_error) {
    output.textContent = 'خطا در ارتباط با میزبان محلی';
  }
});
