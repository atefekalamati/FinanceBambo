"""FastAPI-level smoke tests; also discovered by the one-command runner."""

import sys
import subprocess
import unittest
from pathlib import Path

MOCK_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(MOCK_ROOT))


class FastApiSmokeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            from fastapi.testclient import TestClient
            from app.main import app
        except ImportError:
            cls.client = None
        else:
            cls.client = TestClient(app)

    def test_health_and_marker(self):
        if self.client is None:
            completed = subprocess.run([sys.executable, str(MOCK_ROOT / "run_local.py"), "--self-check"], capture_output=True, text=True, timeout=10)
            self.assertEqual(0, completed.returncode, completed.stderr)
            self.assertIn("SELF_CHECK_OK", completed.stdout)
            return
        response = self.client.get("/mock/health")
        self.assertEqual(200, response.status_code)
        self.assertIn("NOT A PRODUCTION BAMBO ENDPOINT", response.json()["contractMarker"])

    def test_no_finance_user_is_denied(self):
        if self.client is None:
            from app.service import ContractError, project_context
            with self.assertRaises(ContractError):
                project_context("no-finance", "11111111-1111-4111-8111-111111111111", "sample_site_01")
            return
        response = self.client.get(
            "/mock/organizations/11111111-1111-4111-8111-111111111111/projects/sample_site_01",
            headers={"X-Mock-User": "no-finance"},
        )
        self.assertEqual(403, response.status_code)


if __name__ == "__main__":
    unittest.main()
