import json
import sys
import unittest
from decimal import Decimal
from pathlib import Path

KIT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(KIT_ROOT / "mock-host"))

from app.data import ORG_A, PROJECT_A
from app.domain_contracts import append_price, confirm_draft, consumed_quantity, draft_financial_effect, immutable_report_snapshot, invoice_line, resolve_conversion
from app.service import ContractError, load_feed, project_context


class ContractTests(unittest.TestCase):
    def load(self, name):
        return json.loads((KIT_ROOT / "samples" / name).read_text(encoding="utf-8"))

    def test_03_user_without_finance_permission_is_denied(self):
        with self.assertRaises(ContractError) as caught:
            project_context("no-finance", ORG_A, PROJECT_A)
        self.assertEqual(403, caught.exception.status)

    def test_05_task_progress_fallback(self):
        assignment = self.load("progress-feed-task-only.json")["assignments"][0]
        value, source = consumed_quantity({**assignment, "actualQuantity": None})
        self.assertEqual((Decimal("2500"), "task_progress_fallback"), (value, source))

    def test_06_assignment_actual_work_or_quantity(self):
        assignment = self.load("progress-feed-assignment-level.json")["assignments"][0]
        value, source = consumed_quantity(assignment)
        self.assertEqual((Decimal("48"), "assignment_actual"), (value, source))

    def test_07_manual_override_requires_audit(self):
        assignment = self.load("progress-feed-manual-override.json")["assignments"][0]
        self.assertEqual(Decimal("315"), consumed_quantity(assignment)[0])
        assignment["manualOverride"]["reason"] = ""
        with self.assertRaises(ValueError):
            consumed_quantity(assignment)

    def test_08_price_change_does_not_change_historical_invoice(self):
        old = ({"versionId": "p1", "amountIRR": "100", "effectiveFrom": "2026-01-01"},)
        line = invoice_line("2", old[0]["amountIRR"], old[0]["versionId"])
        newer = append_price(old, "140", "2026-02-01", "p2")
        self.assertEqual("200", line["lineAmountIRR"])
        self.assertEqual("100", line["unitPriceIRRSnapshot"])
        self.assertEqual(old[0], newer[0])
        self.assertEqual(2, len(newer))

    def test_09_unconfirmed_extraction_has_zero_effect(self):
        draft = self.load("invoice-image-draft.json")
        self.assertEqual(Decimal("0"), draft_financial_effect(draft))

    def test_10_image_and_voice_remain_draft_until_confirmation(self):
        for name in ("invoice-image-draft.json", "invoice-voice-draft.json"):
            draft = self.load(name)
            self.assertEqual("awaitingReview", draft["reviewStatus"])
            self.assertEqual("awaitingConfirmation", draft["invoiceStatus"])
            self.assertIsNone(draft["confirmedAt"])
        draft = self.load("invoice-image-draft.json")
        confirmed = confirm_draft(draft, draft["submittedBy"], "2026-08-04T10:00:00Z", "1250000")
        self.assertEqual("accepted", confirmed["reviewStatus"])
        self.assertEqual("confirmed", confirmed["invoiceStatus"])
        self.assertEqual("1250000", confirmed["financialEffectIRR"])
        self.assertEqual("0", draft["financialEffectIRR"])

    def test_11_general_cost_without_physical_quantity(self):
        general = self.load("progress-feed-task-only.json")["assignments"][1]
        self.assertEqual("general_cost", general["resourceType"])
        self.assertIsNone(general["plannedQuantity"])
        self.assertIsNone(general["unit"])

    def test_12_ton_to_kilogram(self):
        rows = self.load("unit-conversions.json")["conversions"]
        self.assertEqual(Decimal("1000"), resolve_conversion(rows, ORG_A, PROJECT_A, "ton", "kg"))

    def test_13_project_equipment_day_override(self):
        rows = self.load("unit-conversions.json")["conversions"]
        self.assertEqual(Decimal("10"), resolve_conversion(rows, ORG_A, PROJECT_A, "equipment_day", "hour"))

    def test_14_report_snapshot_pins_immutable_versions(self):
        payload = {"immutable": True, "progressSnapshotId": "s1", "resourceVersionIds": ["r1"], "priceVersionIds": ["p1"], "invoiceIds": ["i1"], "unitConversionIds": ["u1"], "calculatedMetrics": {"actual": "10"}}
        snapshot = immutable_report_snapshot(payload)
        with self.assertRaises(TypeError):
            snapshot["progressSnapshotId"] = "s2"

    def test_progress_feed_is_read_only_copy(self):
        first = load_feed(KIT_ROOT, "finance-viewer", ORG_A, PROJECT_A, "task-only")
        first["assignments"][0]["resourceName"] = "changed"
        second = load_feed(KIT_ROOT, "finance-viewer", ORG_A, PROJECT_A, "task-only")
        self.assertNotEqual("changed", second["assignments"][0]["resourceName"])

    def test_money_contract_rejects_fractional_irr(self):
        with self.assertRaises(ValueError):
            invoice_line("1", "100.5", "p1")


if __name__ == "__main__":
    unittest.main()
