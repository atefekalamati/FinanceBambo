"""One-command offline validation and contract/security test runner."""

from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

KIT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(KIT_ROOT / "tests"))
from schema_tools import validate, validate_schema_document

SAMPLE_SCHEMA = {
    "user-context.json": "user-context.schema.json",
    "organization.json": "organization-context.schema.json",
    "project.json": "project-context.schema.json",
    "progress-feed-task-only.json": "finance-resource-feed.schema.json",
    "progress-feed-assignment-level.json": "finance-resource-feed.schema.json",
    "progress-feed-manual-override.json": "finance-resource-feed.schema.json",
    "unit-conversions.json": "unit-conversion.schema.json",
    "invoice-image-draft.json": "ai-extraction-draft.schema.json",
    "invoice-voice-draft.json": "ai-extraction-draft.schema.json"
}


class ArtifactValidationTests(unittest.TestCase):
    def test_19_all_json_and_samples_validate(self):
        for path in KIT_ROOT.rglob("*.json"):
            json.loads(path.read_text(encoding="utf-8"))
        schema_documents = {}
        for schema_path in (KIT_ROOT / "schemas").glob("*.schema.json"):
            document = json.loads(schema_path.read_text(encoding="utf-8"))
            schema_documents[document["$id"]] = document
        optional_validator = None
        try:
            import jsonschema
            optional_validator = jsonschema
        except ImportError:
            pass
        for sample_name, schema_name in SAMPLE_SCHEMA.items():
            schema_path = KIT_ROOT / "schemas" / schema_name
            schema = json.loads(schema_path.read_text(encoding="utf-8"))
            instance = json.loads((KIT_ROOT / "samples" / sample_name).read_text(encoding="utf-8"))
            validate(instance, schema, schema, schema_path)
            if optional_validator:
                resolver = optional_validator.RefResolver.from_schema(schema, store=schema_documents)
                optional_validator.Draft202012Validator(schema, resolver=resolver, format_checker=optional_validator.FormatChecker()).validate(instance)

    def test_all_json_schemas_are_valid_documents(self):
        for path in (KIT_ROOT / "schemas").glob("*.schema.json"):
            schema = json.loads(path.read_text(encoding="utf-8"))
            validate_schema_document(schema, path)
            try:
                import jsonschema
            except ImportError:
                continue
            jsonschema.Draft202012Validator.check_schema(schema)

    def test_20_all_openapi_files_parse(self):
        for path in (KIT_ROOT / "openapi").glob("*.openapi.yaml"):
            document = json.loads(path.read_text(encoding="utf-8"))  # JSON is valid YAML 1.2
            self.assertEqual("3.1.0", document["openapi"])
            self.assertIn("info", document)
            self.assertIn("paths", document)

    def test_manifest_lists_every_distributable_file(self):
        manifest = json.loads((KIT_ROOT / "MANIFEST.json").read_text(encoding="utf-8"))
        actual = sorted(str(path.relative_to(KIT_ROOT)).replace("\\", "/") for path in KIT_ROOT.rglob("*") if path.is_file() and "dist" not in path.parts and path.name != "MANIFEST.json" and "__pycache__" not in path.parts)
        self.assertEqual(actual, sorted(manifest["files"]))


def suite() -> unittest.TestSuite:
    loader = unittest.TestLoader()
    combined = unittest.TestSuite()
    combined.addTests(loader.loadTestsFromTestCase(ArtifactValidationTests))
    for folder in (KIT_ROOT / "tests" / "contract", KIT_ROOT / "tests" / "security", KIT_ROOT / "mock-host" / "tests"):
        combined.addTests(loader.discover(str(folder), pattern="test_*.py", top_level_dir=str(folder)))
    return combined


if __name__ == "__main__":
    result = unittest.TextTestRunner(verbosity=2).run(suite())
    print(f"SUMMARY total={result.testsRun} failures={len(result.failures)} errors={len(result.errors)} skipped={len(result.skipped)}")
    raise SystemExit(0 if result.wasSuccessful() else 1)
