"""Offline validator for the JSON-Schema subset used by this kit.

When the optional `jsonschema` package is installed the test runner uses it too;
this module keeps parsing and core contract checks runnable without downloads.
"""

from __future__ import annotations

import json
import re
from datetime import date, datetime
from pathlib import Path
from urllib.parse import urlparse
from uuid import UUID


class ValidationFailure(AssertionError):
    pass


def _is_type(value, expected: str) -> bool:
    return {
        "object": isinstance(value, dict), "array": isinstance(value, list), "string": isinstance(value, str),
        "integer": isinstance(value, int) and not isinstance(value, bool), "number": isinstance(value, (int, float)) and not isinstance(value, bool),
        "boolean": isinstance(value, bool), "null": value is None,
    }[expected]


def _resolve_ref(ref: str, schema: dict, schema_path: Path, cache: dict[Path, dict]) -> tuple[dict, dict, Path]:
    if ref.startswith("#/"):
        target = schema
        for part in ref[2:].split("/"):
            target = target[part.replace("~1", "/").replace("~0", "~")]
        return target, schema, schema_path
    file_ref, _, fragment = ref.partition("#")
    target_path = (schema_path.parent / file_ref).resolve()
    target_root = cache.setdefault(target_path, json.loads(target_path.read_text(encoding="utf-8")))
    target = target_root
    if fragment.startswith("/"):
        for part in fragment[1:].split("/"):
            target = target[part.replace("~1", "/").replace("~0", "~")]
    return target, target_root, target_path


def validate(instance, rule: dict, schema: dict, schema_path: Path, cache=None, at="$", collect_errors=False):
    cache = cache or {schema_path.resolve(): schema}
    try:
        if rule is True:
            return
        if rule is False:
            raise ValidationFailure(f"{at}: false schema rejects every value")
        if "$ref" in rule:
            target, root, path = _resolve_ref(rule["$ref"], schema, schema_path, cache)
            return validate(instance, target, root, path, cache, at)
        if "const" in rule and instance != rule["const"]:
            raise ValidationFailure(f"{at}: expected const {rule['const']!r}")
        if "enum" in rule and instance not in rule["enum"]:
            raise ValidationFailure(f"{at}: value not in enum")
        if "type" in rule:
            allowed = rule["type"] if isinstance(rule["type"], list) else [rule["type"]]
            if not any(_is_type(instance, item) for item in allowed):
                raise ValidationFailure(f"{at}: expected type {allowed}")
        if "oneOf" in rule:
            matches = 0
            for option in rule["oneOf"]:
                try: validate(instance, option, schema, schema_path, cache, at)
                except ValidationFailure: pass
                else: matches += 1
            if matches != 1: raise ValidationFailure(f"{at}: expected exactly one oneOf match, got {matches}")
        for condition in rule.get("allOf", []):
            if "if" in condition:
                try: validate(instance, condition["if"], schema, schema_path, cache, at)
                except ValidationFailure: branch = condition.get("else")
                else: branch = condition.get("then")
                if branch: validate(instance, branch, schema, schema_path, cache, at)
            else: validate(instance, condition, schema, schema_path, cache, at)
        if isinstance(instance, dict):
            for key in rule.get("required", []):
                if key not in instance: raise ValidationFailure(f"{at}: missing {key}")
            props = rule.get("properties", {})
            for key, value in instance.items():
                if key in props: validate(value, props[key], schema, schema_path, cache, f"{at}.{key}")
                elif rule.get("additionalProperties") is False: raise ValidationFailure(f"{at}: unexpected {key}")
                elif isinstance(rule.get("additionalProperties"), dict): validate(value, rule["additionalProperties"], schema, schema_path, cache, f"{at}.{key}")
            if len(instance) < rule.get("minProperties", 0): raise ValidationFailure(f"{at}: too few properties")
        if isinstance(instance, list):
            if len(instance) < rule.get("minItems", 0): raise ValidationFailure(f"{at}: too few items")
            if rule.get("uniqueItems") and len({json.dumps(item, sort_keys=True) for item in instance}) != len(instance): raise ValidationFailure(f"{at}: duplicate items")
            if isinstance(rule.get("items"), dict):
                for index, value in enumerate(instance): validate(value, rule["items"], schema, schema_path, cache, f"{at}[{index}]")
        if isinstance(instance, str):
            if len(instance) < rule.get("minLength", 0): raise ValidationFailure(f"{at}: too short")
            if "pattern" in rule and re.search(rule["pattern"], instance) is None: raise ValidationFailure(f"{at}: pattern mismatch")
            fmt = rule.get("format")
            if fmt == "uuid": UUID(instance)
            elif fmt == "date": date.fromisoformat(instance)
            elif fmt == "date-time": datetime.fromisoformat(instance.replace("Z", "+00:00"))
        if isinstance(instance, (int, float)) and not isinstance(instance, bool):
            if "minimum" in rule and instance < rule["minimum"]: raise ValidationFailure(f"{at}: below minimum")
            if "maximum" in rule and instance > rule["maximum"]: raise ValidationFailure(f"{at}: above maximum")
    except (ValueError, KeyError, TypeError) as exc:
        raise ValidationFailure(f"{at}: {exc}") from exc


def validate_schema_document(schema: dict, path: Path):
    required = ("$schema", "$id", "title", "type")
    if any(key not in schema for key in required): raise ValidationFailure(f"{path.name}: incomplete schema metadata")
    if schema["$schema"] != "https://json-schema.org/draft/2020-12/schema": raise ValidationFailure(f"{path.name}: wrong dialect")
    parsed = urlparse(schema["$id"])
    if parsed.scheme != "https" or parsed.hostname != "example.invalid": raise ValidationFailure(f"{path.name}: unsafe schema id")
