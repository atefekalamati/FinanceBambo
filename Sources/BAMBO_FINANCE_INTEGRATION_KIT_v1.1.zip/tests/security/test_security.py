import json
import sys
import unittest
from pathlib import Path

KIT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(KIT_ROOT / "mock-host"))

from app.data import ORG_A, ORG_B, PROJECT_A, PROJECT_A_OTHER, PROJECT_B
from app.service import ContractError, FILES, get_file, project_context, upload_file


class SecurityTests(unittest.TestCase):
    def setUp(self): FILES.clear()

    def test_01_cross_organization_context_denied(self):
        with self.assertRaises(ContractError) as caught: project_context("org-head", ORG_B, PROJECT_B)
        self.assertEqual(403, caught.exception.status)

    def test_02_cross_project_membership_denied(self):
        with self.assertRaises(ContractError) as caught: project_context("org-head", ORG_A, PROJECT_A_OTHER)
        self.assertEqual(403, caught.exception.status)

    def test_04_body_scope_cannot_override_path_scope(self):
        # The service accepts only validated path scope; there are no body-scope arguments.
        metadata = upload_file("finance-editor", ORG_A, PROJECT_A, "invoice_image", "sample.png", b"\x89PNG\r\n\x1a\nsynthetic")
        malicious_body = {"organizationId": ORG_B, "projectId": PROJECT_B}
        self.assertEqual(ORG_A, metadata["organizationId"])
        self.assertEqual(PROJECT_A, metadata["projectId"])
        self.assertNotEqual(malicious_body["organizationId"], metadata["organizationId"])

    def test_15_cross_organization_file_access_is_hidden(self):
        metadata = upload_file("finance-editor", ORG_A, PROJECT_A, "invoice_image", "sample.png", b"\x89PNG\r\n\x1a\nsynthetic")
        with self.assertRaises(ContractError) as caught: get_file("other-organization", ORG_A, PROJECT_A, metadata["fileId"])
        self.assertEqual((404, "NOT_FOUND"), (caught.exception.status, caught.exception.code))

    def test_16_cross_project_file_access_is_hidden(self):
        metadata = upload_file("finance-editor", ORG_A, PROJECT_A, "invoice_image", "sample.png", b"\x89PNG\r\n\x1a\nsynthetic")
        with self.assertRaises(ContractError) as caught: get_file("org-head", ORG_A, PROJECT_A_OTHER, metadata["fileId"])
        self.assertEqual(404, caught.exception.status)

    def test_17_file_metadata_has_both_scope_owners(self):
        metadata = upload_file("finance-editor", ORG_A, PROJECT_A, "invoice_voice", "voice.ogg", b"OggSsynthetic")
        self.assertEqual((ORG_A, PROJECT_A), (metadata["organizationId"], metadata["projectId"]))
        self.assertEqual(64, len(metadata["sha256"]))

    def test_18_existing_and_proposed_permissions_are_distinguishable(self):
        contract = (KIT_ROOT / "04_AUTH_AND_PERMISSION_CONTRACT.md").read_text(encoding="utf-8")
        self.assertIn("## EXISTING permissions", contract)
        self.assertIn("## PROPOSED permissions", contract)
        self.assertIn("finance_report.export", contract)
        self.assertIn("finance.confirm_invoice", contract)
        proposed = contract.split("## PROPOSED permissions (not production facts)", 1)[1].split("## Suggested action matrix", 1)[0]
        codes = [line.split("`")[1] for line in proposed.splitlines() if line.startswith("- `")]
        self.assertTrue(codes)
        self.assertTrue(all(code.count(".") == 1 for code in codes), codes)

    def test_rejects_html_disguised_as_image(self):
        with self.assertRaises(ContractError) as caught: upload_file("finance-editor", ORG_A, PROJECT_A, "invoice_image", "invoice.png", b"<html><script>x</script>")
        self.assertEqual(415, caught.exception.status)

    def test_safe_filename_removes_path_and_control_characters(self):
        metadata = upload_file("finance-editor", ORG_A, PROJECT_A, "invoice_image", "..\\bad:name.png", b"\x89PNG\r\n\x1a\nsynthetic")
        self.assertNotIn("\\", metadata["originalNameSafe"])
        self.assertNotIn(":", metadata["originalNameSafe"])

    def test_no_forbidden_external_addresses_or_secrets(self):
        forbidden = tuple("".join(parts) for parts in (
            ("bambo", "_session"), ("pass", "word="), ("api", "_key="),
            ("BEGIN", " PRIVATE KEY"), ("ssh", "-rsa"), ("postgresql", "://"),
        ))
        for path in KIT_ROOT.rglob("*"):
            if path.is_file() and "dist" not in path.parts:
                text = path.read_text(encoding="utf-8", errors="ignore")
                for value in forbidden: self.assertNotIn(value, text, f"{value} in {path}")


if __name__ == "__main__": unittest.main()
